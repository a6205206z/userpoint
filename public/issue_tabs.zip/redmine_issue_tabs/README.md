redmine_issue_tabs
==================

Redmine plugin that enhances issue interface by adding several useful tabs: timelog, time spent, code commits, history
Changelog
  1.1.0:
    * support Redmine 3.0
    * fixed rights for timelog page